using System;

namespace ConsoleApp1
{
    class Shape
    {
        private long numberSides;

        public long NumberSides
        {
            get
            {
                return numberSides;
            }
            set
            {
                numberSides = value;
            }
        }


        public virtual void DrawShape()
        {
            Console.WriteLine("drawing...");
        }
    }
}